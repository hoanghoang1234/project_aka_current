from app import app, db
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session

from app.models.models import User
from app.utils import utils
from app.utils.params import *

import time
import base64
import PIL.Image as Image
import io
import numpy as np
import cv2


@app.route("/", methods=["GET"])
@utils.login_required
def dashboard():
    """
    Description:
        Render the home screen for the user when they log on the system.

    Prerequisite: 
        The user needed to be logged on before taking this action.
    """
    token = request.cookies.get('token')
    # if token:
        # parser = utils.decode_token(token)
        # if parser['role'] == ADMIN_ROLE:
    return render_template("dashboard/dashboard.html")
        # elif parser['role'] == OPERATOR_ROLE:
        #    return render_template("dashboard.html")
    # return render_template("booking.html")


@app.route("/update-profile", methods=["POST"])
@utils.login_required
def update_profile():
    user = User.query.filter(User.username == session.get('username')).first()
    user.fullname = request.form['name']
    user.phone = request.form['phone']
    user.address = request.form['address']
    if 'base64' in request.form['img']:
        img = base64.b64decode(request.form['img'].split(",")[-1])
        nparr = np.fromstring(img, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_ANYCOLOR)
        image = cv2.resize(image, (320, 240))
        pathfile = app.root_path + "/static/avatar/" + \
            session.get('username') + ".png"
        cv2.imwrite(pathfile, image)
        user.avatar = "/static/avatar/" + session.get('username') + ".png"
    if (not request.form['current_pass']) and (not request.form['new_pass']):
        db.session.commit()
        session['name'] = user.fullname
        session['role'] = user.role
        session['avatar'] = user.avatar
        return utils.response_json(
            True,
            message="Update profile successfully",
            code=200,
            data=request.form
        )
    else:
        if utils.check_password(request.form['current_pass'], user.password):
            user.password = utils.encode_bcrypt(request.form['new_pass'])
            db.session.commit()
            session['name'] = user.fullname
            session['role'] = user.role
            session['avatar'] = user.avatar
            return utils.response_json(
                True,
                message="Update profile successfully",
                code=200,
                data=request.form
            )
        else:
            return utils.response_json(
                False,
                message="Update profile failed",
                code=301,
                data=request.form
            )


@app.route("/add-user", methods=["POST"])
def add_user():
    user = User.query.filter(
        User.username == request.form['username'].lower()).first()
    print(user)
    if user or (' ' in request.form['username']):
        return utils.response_json(
            False,
            message="Add User failed! Missing input",
            code=301,
            data=request.form
        )
    else:
        db.session.add(
            User(
                username=request.form['username'],
                password=utils.encode_bcrypt(request.form['password']),
                fullname=request.form['name'],
                time_create=str(time.time()),
                status=ACTIVE_STATUS,
                role=request.form['role'],
                phone=request.form['phone'],
                address=request.form['address'],
                avatar=DEFAULT_AVATAR
            )
        )
        db.session.commit()
        return utils.response_json(
            True,
            message="Add user successfully",
            code=200,
            data=request.form
        )


@app.route("/login", methods=["POST", "GET"])
def login():
    """
    Description (HTTP GET):
        Display login screen to the user

    Description (HTTP POST):
        Process user credentials and log the user on if the credential is 
        correct, otherwise return the user back to the login screen

    Input:
        request.form["username"]: Username in plain text
        request.form["password"]: Password in plain text

    Output:
        Redirect user to dashboard screen if login succeeded
        Redirect user to login screen if login failed

    Prerequisite:
        User not logged in before taking this action
    """
    if request.method == 'GET':
        return render_template('accounts/login.html')
    else:
        if request.form:
            if ("username" in request.form) and ("password" in request.form):
                username, password = request.form['username'].lower(
                ), request.form['password']
                if not (' ' in username):
                    user = User.query.filter(User.username == username).all()
                    if user:
                        if user[0].status == ACTIVE_STATUS:
                            if utils.check_password(password, user[0].password):
                                token = utils.encode_token({'username': username,
                                                            'name': user[0].fullname,
                                                            'role': user[0].role,
                                                            'avatar': user[0].avatar,
                                                            'timestamp': time.time()
                                                            })
                                session['username'] = username
                                session['name'] = user[0].fullname
                                session['role'] = user[0].role
                                session['avatar'] = user[0].avatar
                                resp = make_response(
                                    redirect(url_for('dashboard', _external=True, _scheme=MODE_SYSTEM)))
                                resp.set_cookie('token', token)
                                return resp
    return render_template('accounts/login.html', msg="Invalid username or password")

# @app.route("/update-info", methods=["POST"])
# def update_info():
#     username = request.form['username'].lower()
#     password = request.form['password']
#     users = User.query.filter(User.username == username).all()
#     # for user in users:
#     users[0].password = utils.encode_bcrypt(password)
#     db.session.commit()
#     return {'username': username, 'password': password, 'db': users[0].serialize()}


@app.route("/register", methods=["GET", "POST"])
def register():
    """
    """
    if request.method == "GET":
        return render_template('accounts/register.html')
    if request.form:
        if ("username" in request.form) and ("password" in request.form) and ('confirm_password' in request.form):
            if request.form['password'] == request.form['confirm_password']:
                username, password, fullname = request.form['username'].lower(
                ), request.form['password'], request.form['fullname']
                # print(request.form)
                if not (' ' in username):
                    user = User(
                        username=username,
                        password=utils.encode_bcrypt(password),
                        fullname=fullname,
                        time_create=str(time.time()),
                        status=ACTIVE_STATUS,
                        role=USER_ROLE,
                        avatar=DEFAULT_AVATAR
                    )
                    if User.query.filter(User.username == username).all():
                        return render_template('accounts/register.html', msg="Existed user!")
                    else:
                        db.session.add(user)
                        db.session.commit()
                        return redirect(url_for('login', _external=True, _scheme=MODE_SYSTEM))
        return render_template('accounts/register.html', msg="Invalid username or password")


@app.route("/logout", methods=["GET"])
@utils.login_required
def logout():
    """
    Description:
        Log the user out of the system by delete all associated tokens in the
        backend. Cookie on the frontend will also set to expired.

        After taking this action, the user will be redirected to login 
        screen.

    Prerequisite:
        The user needed to be logged on before taking this action.
    """

    token = request.cookies.get('token')
    if token and 'username' in session:
        session.pop('username', None)
        session.pop('role', None)
        resp = make_response(
            redirect(url_for('login', _external=True, _scheme=MODE_SYSTEM)))
        resp.set_cookie('token', expires=0)
        return resp


@app.route("/employee/<username>/view", methods=["GET"])
@utils.login_required
def employee_view(username):
    """
    Description:
        View a profile of a specific employee

    Input:
        username: Username of the employee

    Output:
        Detail information of the requested employee if the username exist,
        otherwise redirect to 404 screen

    Prerequisite:
        The user needed to be logged on before taking this action.

    """
    # sql = "SELECT * FROM " + USER_TABLE + " WHERE username='" + username + "'"
    # data = db.get_item(sql)
    # profile = ddb.get_item(EMPLOYEE_TABLE_NAME, {'username':username})
    # print(data)
    user = User.query.filter(User.username == username).all()
    if user:
        return render_template("profile.html", profile=user[0].serialize())

    else:
        return redirect(url_for('error_page', _external=True, _scheme=MODE_SYSTEM))


# @app.route("/finished-trip", methods=["GET"])
# @utils.login_required
# def finished_trip_view():
#     return render_template("finished_trip_details.html")


# @app.route("/canceled-trip", methods=["GET"])
# @utils.login_required
# def canceled_trip_view():
#     return render_template("canceled_trip_details.html")


@app.route("/operator/list", methods=["GET"])
@utils.login_required
def operator_list():
    """
    Description: 
        List all operators

    Prerequisite:
        User not logged in before taking this action
    """
    operators = User.query.filter(
        User.role == OPERATOR_ROLE, User.status == ACTIVE_STATUS).all()
    return render_template('operator_list.html', operators=[operator.serialize() for operator in operators])


@app.route("/admin/list", methods=["GET"])
@utils.login_required
def admin_list():
    """
    Description: 
        List all operators

    Prerequisite:
        User not logged in before taking this action
    """
    admins = User.query.filter(User.role == ADMIN_ROLE).all()
    return render_template('admin_list.html', admins=[admin.serialize() for admin in admins])


@app.route("/driver/add", methods=["GET", "POST"])
@utils.login_required
def driver_add():
    return {'data': request.form}


@app.route("/total-users", methods=["GET"])
@utils.login_required
def total_user():
    return {"data": db.session.query(User).count()}
