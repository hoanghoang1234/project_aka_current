from app import app, db
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session
from werkzeug.utils import secure_filename

from app.models.models import Area
from app.utils import utils
from app.utils.params import *
import uuid
import time
import os
import json
import glob
import numpy as np
import pandas as pd


@app.route("/map_tools", methods=["GET"])
@utils.login_required
def map_tools():
    return render_template("tools/map_tools.html")


@app.route("/map_tools2", methods=["GET"])
@utils.login_required
def map_tools2():
    return render_template("tools/map_tools_2.html")


@app.route("/update/waypoint", methods=["POST"])
@utils.login_required
def update_waypoint():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode("utf8"))

    if receive and ('area_id' in receive) and ('format' in receive) and ('data' in receive):
        area = Area.query.filter(Area.area_id == receive['area_id']).first()
        if area != None:
            if area.waypoint_uploaded:
                keys = receive['format']
                data = np.array(receive['data'])
                csv_data = {}
                for i, key in enumerate(keys):
                    csv_data[key] = data[..., i]

                df = pd.DataFrame(csv_data)
                df.to_csv(glob.glob(area.waypoint_path + "/*.csv")
                          [0], index=False, header=True)
                return utils.response_json(
                    False,
                    message="Update waypoint successfully!",
                    code=200,
                    data=receive
                )
    return utils.response_json(
        False,
        message="Update waypoint failed! area don't exist or missing input",
        code=301,
        data=receive
    )

@app.route("/upload/station", methods=["POST"])
@utils.login_required
def upload_station():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode('utf8'))
    
    if receive and ('area_id' in receive) and ('stations' in receive):
        pass