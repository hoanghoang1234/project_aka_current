$(document).ready(function () {
    $("#dt_format").val("");
    $("#response").val("");
    $.ajax({
        method: 'GET',
        url: '/list/api',
        success: function (res) {
            for (var i = 0; i < res.data.length; i++) {
                let id = res.data[i].api_id;
                let name = res.data[i].name;
                let category = res.data[i].category;
                let url = res.data[i].url;
                let method = res.data[i].method;
                let data_format = res.data[i].data_format;
                let response = res.data[i].response;
                console.log(id, category, method);
                $("#api_table").append(
                    $("<tr>").append(
                        $("<td>").text(name),
                        $("<td>").text(category),
                        $("<td>").text(url),
                        $("<td>").text(method),
                        $("<td>").append($('<textarea class="border-0 td-json-format" rows="6" readonly  cols="30"/>').text(JSON.stringify(data_format, undefined, 4))),
                        $("<td>").append($('<textarea class="border-0 td-json-format" rows="6" readonly  cols="30"/>').text(JSON.stringify(response, undefined, 4))),
                        $("<td>").append(
                            $('<div class="btn-group">').append(
                                $("<button class='btn btn-sm btn-danger'>").html('<i class="fas fa-trash"></i>').click(function () {
                                    deleteApi(id)
                                }),
                                $("<button class='btn btn-sm btn-warning'>").html('<i class="fas fa-edit"></i>').click(function () {
                                    editApi(id, name, category, url, method, data_format, response)
                                })
                            )

                        )
                    )
                )
            }
        },
    });
});
function deleteApi(id) {
    $.ajax({
        url: "/delete/api",
        method: "DELETE",
        contentType:"application/json",
        data: JSON.stringify({ api_id: id }),
        success: function (res) {
            if (res.code == 200) {
                location.reload();
            }
        }
    });
}

function editApi(id, name, category, url, method, data_format, response) {
    $('#editModal').modal('show');
    $('input[name="name_e"]').val(name);
    $('input[name="url_e"]').val(url);
    $('select[name="category_e"]').val(category);
    $('select[name="method_e"]').val(method);
    $('textarea[name="dt_format_e"]').val(JSON.stringify(data_format, undefined, 4));
    $('textarea[name="response_e"]').val(JSON.stringify(response, undefined, 4));
    $("#save_e").click(function () {
        $.ajax({
            url: "/update/api",
            method: "PUT",
            data: JSON.stringify({
                api_id: id,
                name: $('input[name="name_e"]').val(),
                url: $('input[name="url_e"]').val(),
                category: $('select[name="category_e"]').val(),
                method: $('select[name="method_e"]').val(),
                dt_format: $('textarea[name="dt_format_e"]').val(),
                response: $('textarea[name="response_e"]').val()
            }),
            contentType: 'application/json',
            success: function (res) {
                if (res.code == 200) {
                    location.reload();
                }
            }
        });
    })
}
