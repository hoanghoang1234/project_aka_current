uwsgi --http 0.0.0.0:8080 --module app:app
