/*
* Start module relative with Users
*/

function ChooseImage() {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = "image/*";
    input.onchange = e => {
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#show_avatar').attr('src', e.target.result);
        }
        reader.readAsDataURL(file);
    }
    input.click();
}

function UpdateProfile() {
    $.ajax({
        url: "/update-profile",
        type: "post",
        dataType: "json",
        data: {
            username: $('#username').val(),
            name: $('#fullname').val(),
            address: $('#address').val(),
            phone: $('#phone').val(),
            img: document.getElementById('show_avatar').src,
            current_pass: $('#current_pass').val(),
            new_pass: $('#new_pass').val()
        },
        success: function (res) {
            if (res.status == "success") {
                location.reload();
            }else{
                alert("Update failed!");
            }
        }
    });
}

function AddOperator() {
    var check = true;
    var username = $('#username').val();
    var name = $('#fullname').val();
    var address = $('#address').val();
    var phone = $('#phone').val();
    var pass = $('#password').val();
    var confirm_pass = $('#confirm_pass').val();
    if (!username) { $('#notify_username').text("required"); check = false; }
    else { $('#notify_username').text(""); }

    if (!name) { $('#notify_fullname').text("required"); check = false; }
    else { $('#notify_fullname').text(""); }

    if (!address) { $('#notify_address').text("required"); check = false; }
    else { $('#notify_address').text(""); }

    if (!phone) { $('#notify_phone').text("required"); check = false; }
    else { $('#notify_phone').text(""); }

    if (!pass) { $('#notify_password').text("required"); check = false; }
    else { $('#notify_password').text(""); }

    if (!confirm_pass) { $('#notify_confirmpass').text("required"); check = false; }
    else { $('#notify_confirmpass').text(""); }

    if (pass && confirm_pass && !(pass == confirm_pass)) { $('#notify_confirmpass').text("Not the same password"); check = false; }

    if (check) {
        $.ajax({
            url: "/add-user",
            type: "post",
            dataType: "json",
            data: {
                username: username,
                name: name,
                address: address,
                phone: phone,
                password: pass,
                role: "OPERATOR"
            },
            success: function (res) {
                if (res.status == "success") {
                    // console.log(res);
                    $('#add_operator').modal('hide');
                    location.reload();
                    // console.log(document.getElementById('operator_table_body'));
                }
            }
        });
    }
}

// -------------------- End Users -----------------------
