from app import app, db
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session
from werkzeug.utils import secure_filename

from app.models.models import Vehicle
from app.models.models import VehicleData
from app.utils import utils
from app.utils.params import *
import uuid
import time
import os
import json
import glob


@app.route("/vehicles", methods=["GET"])
@utils.login_required
def render_vehicle_page():
    return render_template("system/vehicles.html")


@app.route("/list/vehicle", methods=["GET"])
@utils.login_required
def list_vehicle():
    vehicles = Vehicle.query.all()
    return utils.response_json(
        True,
        message="List of vehicles!",
        code=200,
        data=[vehicle.serialize() for vehicle in vehicles]
    )


@app.route("/detail/vehicle", methods=["GET"])
@utils.login_required
def detail_vehicle():
    if request.args and ("vehicle_id" in request.args):
        vehicle_id = request.args.get("vehicle_id")
        vehicle = Vehicle.query.filter(Vehicle.vehicle_id == vehicle_id).first()
        if vehicle:
            return utils.response_json(
                True,
                message="Specs of vehicles!",
                code=200,
                data= vehicle.serialize()
            )
    
    return utils.response_json(
        False,
        message="Existed id",
        code=301,
        data=""
    )

# apply with init vehicle


@app.route("/connect/vehicle", methods=["POST"])
def vehicle_register():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode("utf8"))
    # print(receive['setting'])
    if receive and ('vehicle_id' in receive) and ("settings" in receive):
        if None == Vehicle.query.filter(Vehicle.vehicle_id ==
                                        receive['vehicle_id']).first():
            mqtt_user = uuid.uuid4().hex
            mqtt_pass = utils.password_generate()
            vehicle = Vehicle(
                vehicle_id=receive['vehicle_id'],
                mqtt_user=mqtt_user,
                setting=json.dumps(json.loads(receive['settings'])),
                mqtt_pass=mqtt_pass,
                time_create=str(time.time()),
                status=INACTIVE_STATUS,
                area_id=""
            )

            params_setting = {}
            params_setting['settings'] = {}
            params_setting['settings'] = json.loads(receive['settings'])
            params_setting['timestamp'] = time.time()
            params_setting['received'] = 0

            vehicle_data = VehicleData(
                vehicle_id = receive['vehicle_id'],
                setting_params_msg = json.dumps(params_setting)
            )
            cmd = 'sudo rabbitmqctl add_user "' + mqtt_user + '" "' + mqtt_pass + '"'
            os.system(cmd)

            db.session.add(vehicle)
            db.session.add(vehicle_data)
            db.session.commit()
            return utils.response_json(
                True,
                message="Register successfully!",
                code=200,
                data=vehicle.serialize()
            )
        else:
            return utils.response_json(
                True,
                message="Existed vehicle!",
                code=200,
                data=Vehicle.query.filter(Vehicle.vehicle_id ==
                                          receive['vehicle_id']).first().serialize()
            )

    # Vehicle.query.filter(Vehicle.vehicle_id ==
    #                      request.form['vehicle_id']).delete()
    # db.session.commit()
    return utils.response_json(
        False,
        message="Register fail! Missing input or Existed id",
        code=301,
        data=receive
    )


@app.route("/update/vehicle", methods=['PUT'])
@utils.login_required
def update_vehicle():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode("utf8"))
    if receive and ('vehicle_id' in receive) and ('area_id' in receive) and \
            ('name' in receive):
        vehicle = Vehicle.query.filter(Vehicle.vehicle_id ==
                                       receive['vehicle_id']).first()
        if None != vehicle:
            try:
                vehicle.name = receive['name']
                vehicle.area_id = receive['area_id']
                vehicle.feedback_topic = "vehicle/" + \
                    receive['area_id'] + "/" + \
                    receive['vehicle_id'] + "/update/feedback"
                vehicle.connect_status_topic = "vehicle/" + \
                    receive['area_id'] + "/" + \
                    receive['vehicle_id'] + "/update/connected"
                vehicle.setting_params_topic = "vehicle/" + \
                    receive['area_id'] + "/" + \
                    receive['vehicle_id'] + "/update/setting/params"
                vehicle.setting_params_confirm_topic = "vehicle/" + \
                    receive['area_id'] + "/" + receive['vehicle_id'] + \
                    "/update/setting/params/confirm"
                vehicle.mission_topic = "vehicle/" + \
                    receive['area_id'] + "/" + \
                    receive['vehicle_id'] + "/update/mission"
                vehicle.mission_confirm_topic = "vehicle/" + \
                    receive['area_id'] + "/" + \
                    receive['vehicle_id'] + "/update/mission/confirm"
                vehicle.init_system_topic = "vehicle/" + \
                    receive['area_id'] + "/" + \
                    receive['vehicle_id'] + "/update/init/system"
                vehicle.init_system_confirm_topic = "vehicle/" + \
                    receive['area_id'] + "/" + receive['vehicle_id'] + \
                    "/update/init/system/confirm"
                db.session.commit()
                return utils.response_json(
                    True,
                    message="update successfully!",
                    code=200,
                    data=vehicle.serialize()
                )
            except:
                return utils.response_json(
                    False,
                    message="Update fail! info input don't json format",
                    code=301,
                    data=receive
                )
    return utils.response_json(
        False,
        message="Update fail! Missing input or Existed id",
        code=301,
        data=receive
    )


@app.route("/active/vehicle", methods=["PUT"])
@utils.login_required
def active_vehicle():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode("utf8"))

    if receive and ('vehicle_id' in receive) and ('status' in receive):
        vehicle = Vehicle.query.filter(Vehicle.vehicle_id ==
                                       receive['vehicle_id']).first()

        if (vehicle != None) and (vehicle.status == INACTIVE_STATUS) and ('ACTIVE' == receive['status']):
            vehicle.status = ACTIVE_STATUS
            cmd = 'sudo rabbitmqctl set_permissions -p "akadrive_vhost" "' + \
                vehicle.mqtt_user + '" ".*" ".*" ".*"'
            os.system(cmd)
            db.session.commit()

            return utils.response_json(
                True,
                message="Active vehicle successfully!",
                code=200,
                data=receive
            )
        elif (vehicle != None) and (vehicle.status == ACTIVE_STATUS) and ("DEACTIVE" == receive['status']):
            # print(receive)
            vehicle.status = INACTIVE_STATUS
            os.system('sudo rabbitmqctl clear_permissions -p "akadrive_vhost" "' +
                      vehicle.mqtt_user + '"')
            db.session.commit()
            return utils.response_json(
                True,
                message="Deactive vehicle successfully!",
                code=200,
                data=receive
            )

    return utils.response_json(
        False,
        message="Active vehicle fail! Missing input or not existed id",
        code=301,
        data=receive
    )


@app.route("/delete/vehicle", methods=["DELETE"])
@utils.login_required
def delete_vehicle():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode("utf8"))

    if receive and ('vehicle_id' in receive):
        vehicle = Vehicle.query.filter(Vehicle.vehicle_id ==
                                       receive['vehicle_id']).first()
        if vehicle:
            Vehicle.query.filter(Vehicle.vehicle_id ==
                                 receive['vehicle_id']).delete()
            os.system('sudo rabbitmqctl clear_permissions -p "akadrive_vhost" "' +
                      vehicle.mqtt_user + '"')
            os.system('sudo rabbitmqctl delete_user "' +
                      vehicle.mqtt_user + '"')
            VehicleData.query.filter(VehicleData.vehicle_id==receive['vehicle_id']).delete()
            db.session.commit()
            return utils.response_json(
                True,
                message="Delete vehicle successfully!",
                code=200,
                data=receive
            )
    return utils.response_json(
        False,
        message="Delete vehicle fail! Missing input or Existed id",
        code=301,
        data=receive
    )
