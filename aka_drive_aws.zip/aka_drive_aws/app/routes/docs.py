from app import app, db
from flask import request, render_template
from flask import make_response, redirect, session, url_for

from app.models.models import API
from app.utils import utils
from app.utils.params import API_TABLE_COLUMN, MODE_SYSTEM

import uuid
import time
import json


@app.route("/document", methods=["GET"])
@utils.login_required
def doc_render():
    return render_template("document/document.html")


@app.route("/add/api", methods=["POST"])
@utils.login_required
def add_api():
    if request.form and all([element in request.form for element in API_TABLE_COLUMN[1:]]):
        try:
            api = API(
                api_id=str(uuid.uuid4().hex),
                name=request.form["name"],
                url=request.form["url"],
                method=request.form['method'].lower(),
                data_format=json.dumps(json.loads(request.form["dt_format"])),
                response=json.dumps(json.loads(request.form["response"])),
                category=request.form['category'],
                time_create=str(time.time())
            )
            db.session.add(api)
            db.session.commit()
            return redirect(url_for('doc_render', _external=True, _scheme=MODE_SYSTEM))
        except:
            return render_template("document/document.html", msg="Add API document failed")


@app.route("/update/api", methods=["PUT"])
@utils.login_required
def update_api():
    receive = json.loads(request.data.decode("utf8"))
    if receive and all([element in receive for element in API_TABLE_COLUMN]):
        api = API.query.filter(API.api_id == receive["api_id"]).first()
        if api:
            api.name = receive["name"]
            api.url = receive["url"]
            api.data_format = json.dumps(json.loads(receive["dt_format"]))
            api.response = json.dumps(json.loads(receive["response"]))
            api.method = receive['method']
            api.category = receive['category']
            db.session.commit()
            return utils.response_json(
                True,
                message="Update API successfully",
                code=200,
                data=api.serialize()
            )
    return utils.response_json(
        False,
        message="Update API failed! Missing input or API not existed",
        code=301,
        data=receive
    )


@app.route("/list/api", methods=["GET"])
@utils.login_required
def view_api():
    apis = API.query.all()
    return utils.response_json(
        True,
        message="",
        code=200,
        data=[api.serialize() for api in apis]
    )


@app.route("/delete/api", methods=["DELETE"])
@utils.login_required
def delete_api():
    receive = json.loads(request.data.decode("utf8"))
    # receive = request.form.to_dict()
    if receive and ("api_id" in receive):
        API.query.filter(API.api_id == receive["api_id"]).delete()
        db.session.commit()
        return utils.response_json(
            True,
            message="Delete API document successfully",
            code=200,
            data=receive
        )
    return utils.response_json(
        False,
        message="Delete API document failed! Missing input",
        code=301,
        data=receive
    )
