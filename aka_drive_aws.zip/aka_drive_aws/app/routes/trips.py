from app import app, db
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session

from datetime import datetime
from datetime import date
from datetime import timedelta

from app.models.models import Trip
from app.utils import utils
from app.utils.params import *

from sqlalchemy import desc, func


import time
import json

g_vehicle_feeback = {'data':[]}
g_waypoint_final = {'data': [],
                    'timestamp': 0}

@app.route("/booking", methods=["POST"])
@utils.login_required
def recieve_booking():
    try:
        if request.args.get("type") == "order":
            data = json.loads(request.data.decode('utf8'))
            # count = db.session.query(Trip).count()

            obj = db.session.query(Trip).order_by(Trip.trip_id.desc()).first()
            username = session.get('username')
            count = 0
            if obj:
                count = obj.trip_id + 1
            # print(data)
            trip = Trip(
                    trip_id=int(count),
                    trip_name=data['trip_name'],
                    info=json.dumps(data),
                    time_create=str(time.time()),
                    username=username,
                    status=OPEN_STATUS
                )
            # print(trip.serialize())
            db.session.add(trip)
            db.session.commit()
            return data
        elif request.args.get("type") == "cancel":
            username = session.get('username')
            trips = Trip.query.filter(Trip.username == username, Trip.status != DONE_STATUS, Trip.status != CANCEL_STATUS).all()
            if trips:
                for trip in trips:
                    trip.status = CANCEL_STATUS
                db.session.commit()
            return {"message": "Cancel from user Success!"}
    except:
        return "Failed"

@app.route("/booking-state", methods=["GET"])
@utils.login_required
def booking_state():
    username = session.get('username')
    trips = Trip.query.filter(Trip.username == username, Trip.status != DONE_STATUS, Trip.status != CANCEL_STATUS).all()
    if trips:
        return {'data': json.loads(trips[0].info)}
    else:
        return {"data": []}

@app.route("/get-booking", methods=["GET"])
def send_booking():
    # trips = Trip.query.filter(Trip.status != DONE_STATUS, Trip.status != CANCEL_STATUS).all()
    trips = Trip.query.filter(Trip.status == OPEN_STATUS).all()
    res = {'data':[]}
    for trip in trips:
        if trip.time_create > str(int(time.time()) - 1800):
            trip_list = trip.serialize()
            data = trip_list['info']
            data['id'] = str(trip_list['trip_id'])
            res['data'].append(data)
            trip.status = PROGRESS_STATUS
        else:
            trip.status = DONE_STATUS
    db.session.commit()
    return res

# receive feedback from vehicle
@app.route("/trip-finish", methods=["POST"])
def trip_finish():
    try:
        id_ = request.args.get("id")
        if id_:
            trips = Trip.query.filter(Trip.status == PROGRESS_STATUS).all()
            for trip in trips:
                if str(trip.trip_id) in id_:
                    trip.status = DONE_STATUS
            db.session.commit()
            return "Sucess"
    except:
        return "Failed"

@app.route("/finished-trips", methods=["GET"])
@utils.login_required
def finished_trip():
    time_format = "%Y:%m:%d:%H:%M:%S"
    start_time_str = date.today().strftime(time_format)
    start_time = utils.datetime2timestamp(start_time_str, time_format)
    trips = Trip.query.filter(Trip.time_create >= str(start_time), Trip.status == DONE_STATUS).all()
    output= []
    for trip in trips:
        output.append(trip.serialize())
    return {"data": len(trips), 'trips': output}

@app.route("/active-trips", methods=["GET"])
@utils.login_required
def active_trip():
    time_format = "%Y:%m:%d:%H:%M:%S"
    start_time_str = date.today().strftime(time_format)
    start_time = utils.datetime2timestamp(start_time_str, time_format)
    trips = Trip.query.filter(Trip.time_create >= str(start_time), Trip.status == PROGRESS_STATUS).all()
    output = []
    for trip in trips:
        output.append(trip.serialize())
    return {"data": len(trips), 'trips': output}

@app.route("/cancelled-trips", methods=["GET"])
@utils.login_required
def cancelled_trips():
    time_format = "%Y:%m:%d:%H:%M:%S"
    start_time_str = date.today().strftime(time_format)
    start_time = utils.datetime2timestamp(start_time_str, time_format)
    trips = Trip.query.filter(Trip.time_create >= str(start_time), Trip.status == CANCEL_STATUS).all()
    output= []
    for trip in trips:
        output.append(trip.serialize())
    return {"data": len(trips), 'trips': output}

# receive cancel request from app booking
# @app.route("/cancelled-trip", methods=["POST"])
# @utils.login_required
# def user_cancel_trip():
#     token = request.cookies.get('token')
#     if token:
#         parser = utils.decode_token(token)
#         username = parser['username']
#         trips = Trip.query.filter(Trip.username == username, Trip.status == PROGRESS_STATUS).all()
#         if trips:
#             for trip in trips:
#                 trip.status = CANCEL_STATUS
#             db.session.commit()
#         return "Success"
#     return "Failed"

@app.route("/report-trips-on-7days", methods=["GET"])
@utils.login_required
def report_trips():
    time_format = "%Y:%m:%d:%H:%M:%S"
    start_time_datetime = (date.today() - timedelta(days=7)) # get previous 7 days from today
    start_time = utils.datetime2timestamp(start_time_datetime.strftime(time_format), time_format)
    trips = Trip.query.filter(Trip.time_create >= str(start_time), Trip.status != OPEN_STATUS, Trip.status != PROGRESS_STATUS).all()
    res = {'data':[]}
    previous_time = 0
    for i in range(1, 8, 1):
        focus_date = (start_time_datetime + timedelta(days=(1+i)))
        temp = utils.datetime2timestamp(focus_date.strftime(time_format), time_format)
        cancel_count = 0
        done_count = 0
        for trip in trips:
            if (trip.time_create >= str(previous_time)) and (trip.time_create < str(temp)):
                if trip.status == DONE_STATUS:
                    done_count = done_count + 1
                else:
                    cancel_count = cancel_count + 1
        previous_time = temp
        res['data'].append({'date': (start_time_datetime + timedelta(days=(i))).strftime("%m/%d"),
                            'finish': done_count,
                            'cancel': cancel_count
                            })
    return res

@app.route("/waypoint-ggmap-info", methods = ["POST"])
def waypoint_ggmap_info():
    try:
        if request.args.get('area'):
            root_path = app.root_path
            json_file = root_path + "/static/json/" + request.args.get('area') + ".json"
            with open(json_file, "r") as read_file:
                data = json.load(read_file)
                return data
    except:
        return {"waypoints": [], "ggmap_waypoint": []}
    return {"waypoints": [], "ggmap_waypoint": []}

@app.route("/station", methods=["POST"])
# @utils.login_required
def get_station():
    try:
        if request.args.get('area'):
            root_path = app.root_path
            json_file = root_path + "/static/json/" + request.args.get('area') + ".json"
            with open(json_file, "r") as read_file:
                data = json.load(read_file)
                return {"data" : data['stations']}
    except:
        return {"data" : []}
    return {"data": []}
 
@app.route("/vehicle-feedback", methods=["GET", "POST"])
def current_position():
    if request.method == "GET":
        # print(g_vehicle_feeback)
        if g_vehicle_feeback['data']:
            year_fb, month_fb,date_fb,hour_fb,minute_fb = [int(v) for v in datetime.fromtimestamp(g_vehicle_feeback['data'][-1]).strftime('%Y:%m:%d:%H:%M').split(":")]
            # print(date_fb,hour_fb,minute_fb) 
             # = object_date
            year_cur, month_cur,date_cur,hour_cur,minute_cur = [int(v) for v in datetime.fromtimestamp(time.time()).strftime('%Y:%m:%d:%H:%M').split(":")]
            if (year_fb == year_cur) and (month_fb == month_cur) and \
                (date_fb == date_cur) and (hour_fb == hour_cur) \
                and ((minute_fb + 3) >= minute_cur):
                print("valid Ok")
                return g_vehicle_feeback
            else:
                print('timeout datafeedback')
                return {'data':[]}
        return g_vehicle_feeback
    else:
        # print("vehicle fb post methods")
        data = json.loads(request.data.decode('utf8'))['data']
        data.append(time.time())
        g_vehicle_feeback['data'] = data
        return g_vehicle_feeback

@app.route("/waypoints-final", methods=["GET", "POST"])
def waypoint_final():
    if request.method == "GET":
        time_format = "%Y:%m:%d:%H:%M:%S"
        start_time_str = date.today().strftime(time_format)
        start_time = utils.datetime2timestamp(start_time_str, time_format)
        trips = Trip.query.filter(Trip.time_create >= str(start_time), Trip.status == PROGRESS_STATUS).all()
        print("len waypoint: ", len(g_waypoint_final['data']))
        #print(g_waypoint_final)
        if trips and g_waypoint_final['data']:
            return g_waypoint_final
        g_waypoint_final['data'] = []
        g_waypoint_final['timestamp'] = time.time()
        return g_waypoint_final
    else:
        # print("dkm nhan waypoint final")
        data = json.loads(request.data.decode('utf8'))['data']
        g_waypoint_final['data'] = data
        g_waypoint_final['timestamp'] = time.time()
        return g_waypoint_final
