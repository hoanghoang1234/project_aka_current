
var myChart;
var map, infoWindow;
var initialize_chart = 0;
var initialize_carposition = 0;
var initialize_area = 0;
var area_name = 'fville';
// var myChart;
var numDeltas = 100;
var delay = 10; //milliseconds
var i = 0;
var deltaLat;
var deltaLng;
var car_position;
//----------Utils functions----------
//// smooth car position on googlemap
function transition(result){
    i = 0;
    
    deltaLat = (result[0] - car_position[0])/numDeltas;
    deltaLng = (result[1] - car_position[1])/numDeltas;
    // console.log(result);
    // console.log(car_position);
    moveMarker();
}

function moveMarker(){
    car_position[0] += deltaLat;
    car_position[1] += deltaLng;
    
    var latlng = new google.maps.LatLng(car_position[0], car_position[1]);
    marker.setTitle("Latitude:"+car_position[0]+" | Longitude:"+car_position[1]);
    marker.setPosition(latlng);
    
    if(i!=numDeltas){
        i++;
        setTimeout(moveMarker, delay);
    }
}

function makeAffineTransformFromPoints(hdmap_point, ggmap_point)
{
	var affineTransformation = {
	    rotation: 0,
	    scale: 1,
	    point_of_rotation: 0,
	    point_of_mapping: 0,
	    transform: function (x, y) {
	        x_m = (Math.cos(this.rotation)*(x - this.point_of_rotation[0]) + Math.sin(this.rotation)*(y - this.point_of_rotation[1]))*this.scale + this.point_of_mapping[0];
	        y_m = (-Math.sin(this.rotation)*(x - this.point_of_rotation[0]) + Math.cos(this.rotation)*(y - this.point_of_rotation[1]))*this.scale + this.point_of_mapping[1];
	        return {
	            lat: y_m,
	            lng: x_m
	        }
	    }
	}
    var vector1 = [0, 0]
    var vector2 = [0, 0]
    // vector 1 = (a, b) , vector 2 = (c,d)
    vector1[0] = (hdmap_point[1].x - hdmap_point[0].x)
    vector1[1] = (hdmap_point[1].y - hdmap_point[0].y)
    vector2[0] = (ggmap_point[1].lng - ggmap_point[0].lng)
    vector2[1] = (ggmap_point[1].lat - ggmap_point[0].lat)
    // Math.atan2((b*c-a*d), (a*c+b*d))
    affineTransformation.rotation = Math.atan2((vector1[1]*vector2[0]-vector1[0]*vector2[1]), (vector1[0]*vector2[0]+vector1[1]*vector2[1]))
    // Math.sqrt(c*c + vd*d)/Math.sqrt(a*a + b*b)
    affineTransformation.scale = Math.sqrt(vector2[0]*vector2[0] + vector2[1]*vector2[1])/Math.sqrt(vector1[0]*vector1[0] + vector1[1]*vector1[1])
    affineTransformation.point_of_rotation = [hdmap_point[0].x, hdmap_point[0].y];
    affineTransformation.point_of_mapping = [ggmap_point[0].lng, ggmap_point[0].lat];
    return affineTransformation;
}

function convertFinalWaypointtoLatLng(arrayWaypoint, ggm_waypoint)
{

    part_amount = ggm_waypoint.length;

    var part_size = Math.floor(arrayWaypoint.length/part_amount);
    var start_id = 0;
    var end_id = part_size;

    var hdmap_points_arr = [];  // arr chua cac arr [ {x: , y:}, {x:, y:} ]
    var ggmap_points_arr = [];  // arr chua cac arr [ {lng:, lat:}, {lng: ,lat: }]
    var waypointLatLng   = [];

    for(var i = 0; i < part_amount; i++)
    {
        var hdmap_point1 = {x : undefined, y: undefined}
        var hdmap_point2 = {x : undefined, y: undefined}
        var ggmap_point1 = {lng : undefined, lat: undefined}
        var ggmap_point2 = {lng : undefined, lat: undefined}

        if(i == 0)
        {
            hdmap_point1.x = ggm_waypoint[part_amount - 1][2];
            hdmap_point1.y = ggm_waypoint[part_amount - 1][3];
            ggmap_point1.lng = ggm_waypoint[part_amount - 1][1];
            ggmap_point1.lat = ggm_waypoint[part_amount - 1][0];
        }
        else{
            hdmap_point1.x = ggm_waypoint[i - 1][2];
            hdmap_point1.y = ggm_waypoint[i - 1][3];
            ggmap_point1.lng = ggm_waypoint[i - 1][1];
            ggmap_point1.lat = ggm_waypoint[i - 1][0];
        }

        hdmap_point2.x = ggm_waypoint[i][2];
        hdmap_point2.y = ggm_waypoint[i][3];
        ggmap_point2.lng = ggm_waypoint[i][1];
        ggmap_point2.lat = ggm_waypoint[i][0];

        // console.log("\n hdmap_point2: " + JSON.stringify(hdmap_point2));

        var hdmap_points = [hdmap_point1, hdmap_point2];
        var ggmap_points = [ggmap_point1, ggmap_point2];
        hdmap_points_arr.push(hdmap_points)
        ggmap_points_arr.push(ggmap_points)
    }

    // Transform and save data
    for(var i = 0; i < part_amount; i++)
    {
        if(end_id > arrayWaypoint.length -1)
        {
            end_id = arrayWaypoint.length - 1;
        }

        var affineTransformation = makeAffineTransformFromPoints(hdmap_points_arr[i], ggmap_points_arr[i]);
        var start_point, end_point;
	    if (start_id < end_id)
	    {
	        start_point = start_id;
	        end_point = end_id;
	    }
	    else 
	    {
	        start_point = end_id;
	        end_point = start_id;
	    }
	    for(var j = start_point; j < end_point ; j++)
	    {
	        mapLatLng = affineTransformation.transform(arrayWaypoint[j][0], arrayWaypoint[j][1])
	        waypointLatLng.push({'lat':mapLatLng['lat'], 'lng':mapLatLng['lng']});
	    };
        start_id = end_id;
        end_id += part_size;
    }
    //Note : Sau khi chay toi day ta da co mot waypointLatLng[] duoc convert tu arrayWaypoint[]
    var geojson = {"type": "FeatureCollection",
				  "features": [
				    {
				      "type": "Feature",
				      "properties": {
				        "letter": "G",
				        "color": "blue",
				        "rank": "7",
				        "ascii": "71"
				      },
				      "geometry": {
				        "type": "Polygon",
				        "coordinates": waypointLatLng}}]}
    return waypointLatLng;
}
///////////////////////////////
function init_google_map() {
    var position = { lat: 21.010103, lng: 105.536145 };
    var element = document.getElementById('map');
    if(element != null)
    {
        map = new google.maps.Map(document.getElementById("map"), {
            center: position,
            zoom: 17
        });
        console.log(map);
    }
    
}

// Get information

function get_report_trips_on_week() {
    $.ajax({
        url: "/report-trips-on-7days",
        type: "GET",
        dataType: 'json',
        success: function (data) {
        	var chart_data = {
			    labels: [],
			    datasets: [
			        {
			            label: "Finish",
			            data: [],
			            backgroundColor: 'rgba(78, 115, 223, 1)'
			        },
			        {
			            label: "Cancel",
			            data: [],
			            backgroundColor: 'rgba(246, 194, 62, 1)'
			        }]
			};
            // if (document.getElementById("finished_trip")) { document.getElementById("finished_trip").innerHTML = data.data + " (trips)"; }
            for (var i = 0; i < data.data.length; i++) {
                // console.log(data.data[i]);
                chart_data.labels.push(data.data[i].date);
                chart_data.datasets[0].data.push(data.data[i].finish);
                chart_data.datasets[1].data.push(data.data[i].cancel);
            }
            draw_chart(chart_data);
        }
    });
}
// draw on map
function draw_chart(data) {
	if (!initialize_chart){
	    var ctx = document.getElementById('chart-id');
      var plugins = { datalabels: {
            color: 'white',
            display: function(context) {
              return context.dataset.data[context.dataIndex] > 0;
            },
            font: {
              weight: 'bold'
            },
            formatter: Math.round
          }
        }
	    if (ctx) {
	        var option = {
        	 	  plugins: plugins,
	            maintainAspectRatio: false,
	            responsive: true,
	            scales: {
	                xAxes: [{ stacked: true }],
	                yAxes: [{ stacked: true }]
	            }
	        }
	        myChart = new Chart(ctx, {
	            type: 'bar',
	            data: data,
	            options: option
	        });
	    }
	    initialize_chart = 1;
	}
	else{
        if(myChart != undefined)
        {
            myChart.data.datasets[0].data = data.datasets[0].data;
            myChart.data.datasets[1].data = data.datasets[1].data;
            myChart.update();
        }
		
	}
}

function draw_cars(data){
	// console.log(data)
	if (data.data.length){
		var latlng = new google.maps.LatLng(data.data[0][0], data.data[0][1]);
	    if (!initialize_carposition){
	      car_position = [data.data[0][0], data.data[0][1]]
	      const car_icon = {
	        url : "static/img/logocar.png",
	        origin: new google.maps.Point(0,0),
	        anchor: new google.maps.Point(15,15),
	        size: new google.maps.Size(30,30)};

		      marker = new google.maps.Marker({
		        position: latlng,
		        map: map,
	        icon: car_icon,
		        title: "Latitude:" + car_position[0] + " | Longitude:" + car_position[1]
		      });
	      initialize_carposition = 1;
	      
	    }
	    else{
	      var result = [data.data[0][0], data.data[0][1]];
	      marker.setTitle("Latitude:"+car_position[0]+" | Longitude:"+car_position[1]);
	      marker.setPosition(latlng);
	      // use it if smooth animation
	      // transition(result)
	      initialize_carposition = 1;
	    }
	}
  else{
  	console.log("no cars");
  }
}



// get data from sever
function update_info() {
    $.ajax({
        url: "/finished-trips",
        type: "GET",
        dataType: 'json',
        success: function (data) {
            if (document.getElementById("finished_trip")) { document.getElementById("finished_trip").innerHTML = data.data + " (trips)"; }
            var html = '';
            data.trips.sort((function (a, b) { return new Date(parseFloat(b.time_create)) - new Date(parseFloat(a.time_create)) }));
            var table_rows = 10;
            var index =  ((data.trips.length < table_rows)? data.trips.length: table_rows);

            for(var i = 0; i < index; i++)
            {
                var datetime = new Date(parseFloat(data.trips[i].time_create)*1000);
                html += '<tr>';
                html += '<td>' + data.trips[i].username + '</td>';
                var tripname = data.trips[i].trip_name.split("-"); 
                html += '<td>' + tripname[0] + '</td>';
                html += '<td>' + tripname[1] + '</td>';
                html += '<td>' + datetime.toLocaleString('en-US', { hour12: false }) + '</td>';
                html += '</tr>';
            } 
            $('#finished_trip_table_body').html(html);

        }
    });
    $.ajax({
        url: "/active-trips",
        type: "GET",
        dataType: "json",
        success: function (data) {
            // console.log(data);
            if (document.getElementById("active_trip")) { document.getElementById("active_trip").innerHTML = data.data + " (trips)"; }
            // if (data.trips){
            var html = '';
            data.trips.sort((function (a, b) { return new Date(parseFloat(b.time_create)) - new Date(parseFloat(a.time_create)) }));
            var table_rows = 10;
            var index =  ((data.trips.length < table_rows)? data.trips.length: table_rows);

            for(var i = 0; i < index; i++)
            {
                var datetime = new Date(parseFloat(data.trips[i].time_create)*1000);
                html += '<tr>';
                html += '<td>' + data.trips[i].username + '</td>';
                var tripname = data.trips[i].trip_name.split("-"); 
                html += '<td>' + tripname[0] + '</td>';
                html += '<td>' + tripname[1] + '</td>';
                html += '<td>' + datetime.toLocaleString('en-US', { hour12: false }) + '</td>';
                html += '</tr>';
            } 
            $('#active_bus_table_body').html(html);
            
        }
    });

    $.ajax({
        url: "/cancelled-trips",
        type: "GET",
        dataType: "json",
        success: function (data) {
            // console.log(data);
            if (document.getElementById("cancelled_trips")) { document.getElementById("cancelled_trips").innerHTML = data.data + " (trips)"; }

            var html = '';
            data.trips.sort((function (a, b) { return new Date(parseFloat(b.time_create)) - new Date(parseFloat(a.time_create)) }));
            var table_rows = 10;
            var index =  ((data.trips.length < table_rows)? data.trips.length: table_rows);

            for(var i = 0; i < index; i++)
            {
                var datetime = new Date(parseFloat(data.trips[i].time_create)*1000);
                html += '<tr>';
                html += '<td>' + data.trips[i].username + '</td>';
                var tripname = data.trips[i].trip_name.split("-"); 
                html += '<td>' + tripname[0] + '</td>';
                html += '<td>' + tripname[1] + '</td>';
                html += '<td>' + datetime.toLocaleString('en-US', { hour12: false }) + '</td>';
                html += '</tr>';
            } 
            $('#canceled_trip_table_body').html(html);
        }
    });

    $.ajax({
        url: "/total-users",
        type: "GET",
        dataType: "json",
        success: function (data) {
            // console.log(data);
            if (document.getElementById("users")) { document.getElementById("users").innerHTML = data.data + " (users)"; }
        }
    });
    $.ajax({
        url: "/vehicle-feedback",
        type: "GET",
        dataType: "json",
        success: function (data) {
          draw_cars(data);
          // if (document.getElementById("cancelled_trips")) { document.getElementById("cancelled_trips").innerHTML = data.data + " (trips)"; }
        }
    });

 //    $.ajax({
	// 	url: "/waypoint-ggmap-info" + '?vehicle_id=fville&area=' + area_name,
	// 	type: "POST",
	// 	dataType: 'json',
	// 	success: function(data){
	// 		if (data){
	// 			console.log(data)
	// 	  	arrayWaypoint = data.waypoints;
	// 	    ggm_waypoint =  data.ggmap_waypoint;
	// 	    var waypointLatLng = convertFinalWaypointtoLatLng(arrayWaypoint, ggm_waypoint);
	// 	    if(!initialize_area){
	// 	    // map.data = waypointLatLng;
	// 		    map.data.add({
	// 			    geometry: new google.maps.Data.Polygon([
	// 			      waypointLatLng
	// 			    ])
	// 			  });
	// 			  map.data.setStyle({
	// 			    fillColor: "green",
	// 			    strokeColor: "green",
	// 			    strokeWeight: 0
	// 			  });
	// 			  initialize_area = 1;
	// 			}
	// 		}
	// 		else{
	// 			console.log('no map info');
	// 		}
	// 	}
	// });
}

$(document).ready(function () {

    // $.ajax({
    //     url: "/vehicle-feedback",
    //     type: "GET",
    //     dataType: "json",
    //     success: function (data) {
    //         console.log(data.data);
    //         // if (document.getElementById("cancelled_trips")) { document.getElementById("cancelled_trips").innerHTML = data.data + " (trips)"; }
    //     }
    // });

    // $('#finished_trip').on('click', function(){
    //     console.log("Click vào finished_trip");
    //     if (document.getElementById("finished_trip_container").style.display === "none")
    //         document.getElementById("finished_trip_container").style.display="block";
    //     else
    //         document.getElementById("finished_trip_container").style.display="none";

    //     // $('#active_bus_table').show();


    //     // $('#active_bus_table').dialog('open');
    // });

    // $('#cancelled_trip').on('click', function(){
    //     console.log("Click vào cancelled_trip");
    // });

    // update_info();
    // get_report_trips_on_week();
    init_google_map();
    // setInterval(function(){
    //     update_info();
    //     get_report_trips_on_week();
    // }, 5000); 

    
});

