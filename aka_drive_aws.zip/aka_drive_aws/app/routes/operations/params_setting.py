from app import app, db
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session
from werkzeug.utils import secure_filename

from app.models.models import Vehicle
from app.models.models import VehicleData
from app.utils import utils
from app.utils.params import *
import uuid
import time
import os
import json
import glob


@app.route("/params/setting", methods=["GET"])
@utils.login_required
def params_settings():
    return render_template("operation/parameter_setting.html")


@app.route("/get/params", methods=["GET"])
# @utils.login_required
def upload_params():
    try:
        vehicle_id = request.args.get('vehicle_id')
        vehicle_data = VehicleData.query.filter(
            VehicleData.vehicle_id == vehicle_id).first()
        # print(vehicle_data.serialize())
        if vehicle_data != None:
            return utils.response_json(
                True,
                message="Successfully!",
                code=200,
                data=json.loads(vehicle_data.setting_params_msg)
            )
        return utils.response_json(
            False,
            message="Error!",
            code=301,
            data=''
        )
    except:
        print(request.args.get('vehicle_id'))
        return utils.response_json(
            False,
            message="Error!",
            code=301,
            data=''
        )
