#!/home/ubuntu/fville_final/env/bin/python
from flask import Flask
import mysql.connector

from flask_sqlalchemy import SQLAlchemy
from app.utils.params import *

# Init mysql
mydb = mysql.connector.connect(
    host=MYSQL_HOST,
    user=MYSQL_USERNAME,
    password=MYSQL_PASS
)
mycursor = mydb.cursor()
mycursor.execute("CREATE SCHEMA IF NOT EXISTS " +
                 MYSQL_DB + " DEFAULT CHARACTER SET utf8")
mycursor.close()
mydb.close()

app = Flask(__name__)
app.secret_key = b'TFZa2Tl12p3iCmYSXvfe7p52S1LyZ8oT6LkHjlwS'
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+mysqlconnector://" + \
    MYSQL_USERNAME + ":" + MYSQL_PASS + "@" + \
    MYSQL_HOST + "/" + MYSQL_DB + "?charset=utf8"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

db = SQLAlchemy(app)



from app.routes import users
from app.routes import areas
from app.routes import docs
from app.routes import maps_tool

from app.routes.vehicles import vehicles
from app.routes.vehicles import vehicles_data
from app.routes.operations import params_setting