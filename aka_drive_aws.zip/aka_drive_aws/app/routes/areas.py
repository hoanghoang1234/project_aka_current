from app import app, db
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session
from werkzeug.utils import secure_filename

from app.models.models import Area
from app.models.models import Vehicle
from app.utils import utils
from app.utils.params import *
import uuid
import time
import os
import json
import glob
import pandas as pd


@app.route("/area", methods=["GET"])
@utils.login_required
def area_render_template():
    return render_template("system/areas.html")


@app.route("/add/area", methods=["POST"])
@utils.login_required
def add_new_area():
    if request.form and ("name" in request.form):
        if (not (" " in request.form['name'])) and \
                (None == Area.query.filter(Area.area_id == request.form["name"]).first()):
            area = Area(
                area_id=request.form["name"],
                info=request.form['info'],
                map_uploaded=False,
                waypoint_uploaded=False,
                time_create=str(time.time()),
                status=ACTIVE_STATUS
            )
            db.session.add(area)
            db.session.commit()
            return redirect(url_for("area_render_template", _external=True, _scheme=MODE_SYSTEM))
    return utils.response_json(
        False,
        code=301,
        message="Add area failed! Missing input or include space with area name or existed area name",
        data=request.form
    )


@app.route("/list/area", methods=["GET"])
@utils.login_required
def list_map():
    areas = Area.query.all()
    return utils.response_json(
        True,
        code=200,
        message="List area successfully",
        data=[area.serialize() for area in areas]
    )


@app.route("/delete/area", methods=["DELETE"])
@utils.login_required
def delete_area():
    receive = json.loads(request.data.decode("utf8"))
    if receive and ("area_id" in receive):
        area = Area.query.filter(Area.area_id == receive['area_id']).first()
        vehicle = Vehicle.query.filter(
            Vehicle.area_id == receive['area_id']).first()
        if vehicle == None:
            os.system("rm -rf " + app.root_path +
                      UPLOAD_FOLDER + "/" + receive['area_id'])
            Area.query.filter(Area.area_id == receive['area_id']).delete()
            db.session.commit()

            return utils.response_json(
                True,
                message="Delete Area  successfully",
                code=200,
                data=receive
            )
    return utils.response_json(
        False,
        message="Delete Area failed! Missing input or Area assigned with vehicle",
        code=301,
        data=receive
    )


@app.route("/upload/map", methods=["POST"])
@utils.login_required
def upload_map_pcd():
    if ("files" not in request.files) or \
        ("area_id" not in request.form) or \
            (None == Area.query.filter(Area.area_id == request.form['area_id']).first()):

        return utils.response_json(
            True,
            code=301,
            message="upload map pcd fail or missing area_id/area not exist",
            data=""
        )
    area = Area.query.filter(Area.area_id == request.form['area_id']).first()
    files = request.files.getlist("files")
    path_storage = app.root_path + UPLOAD_FOLDER + \
        "/" + request.form['area_id'] + "/map"
    # print(path_storage)
    if not os.path.exists(path_storage):
        os.system("mkdir -p " + path_storage)

    if glob.glob(path_storage + "/*.pcd"):
        os.system("rm " + path_storage + "/*")

    for file_ in files:
        filename = secure_filename(file_.filename)
        file_.save(os.path.join(path_storage, filename))

    area.map_uploaded = True
    area.map_path = path_storage
    db.session.commit()
    # os.system("zip -r " + area.area_id + ".zip "+ path_storage)
    return utils.response_json(
        True,
        code=200,
        message="upload map pcd successfully",
        data=""
    )


@app.route("/download/map", methods=["GET"])
@utils.login_required
def download_map():
    if request.args and ("area_id" in request.args):
        area = Area.query.filter(
            Area.area_id == request.args.get('area_id')).first()
        if area and area.map_uploaded:
            if not glob.glob(area.map_path + "/*.zip"):
                os.system("zip -r " + area.map_path+"/" +
                          area.area_id + ".zip " + area.map_path)
            return send_from_directory(area.map_path, area.area_id + ".zip", as_attachment=True)

    return utils.response_json(
        False,
        message="Download failed! Mission parameters request area_id or not exist id in database",
        code=301,
        data=""
    )


@app.route("/delete/map", methods=["DELETE"])
@utils.login_required
def delete_map():
    receive = json.loads(request.data.decode("utf8"))
    if receive and ("area_id" in receive):
        area = Area.query.filter(Area.area_id == receive['area_id']).first()
        if area.map_uploaded:
            os.system("rm -rf " + area.map_path)

        area.map_path = ""
        area.map_uploaded = False
        db.session.commit()
        return utils.response_json(
            True,
            message="Delete Map  successfully",
            code=200,
            data=receive
        )
    return utils.response_json(
        False,
        message="Delete Map failed! Missing input",
        code=301,
        data=receive
    )


@app.route("/upload/waypoint", methods=["POST"])
@utils.login_required
def upload_waypoint():
    if ("files" not in request.files) or \
        ("area_id" not in request.form) or \
            (None == Area.query.filter(Area.area_id == request.form['area_id']).first()):

        return utils.response_json(
            True,
            code=301,
            message="upload csv waypoint fail or missing area_id/area not exist",
            data=""
        )
    area = Area.query.filter(Area.area_id == request.form['area_id']).first()
    files = request.files.getlist("files")
    path_storage = app.root_path + UPLOAD_FOLDER + \
        "/" + request.form['area_id'] + "/waypoint"

    if not os.path.exists(path_storage):
        os.system("mkdir -p " + path_storage)

    if glob.glob(path_storage + "/*.csv"):
        os.system("rm " + path_storage + "/*")

    for file_ in files:
        filename = secure_filename(file_.filename)
        file_.save(os.path.join(path_storage, filename))

    area.waypoint_uploaded = True
    area.waypoint_path = path_storage
    db.session.commit()
    # os.system("zip -r " + area.area_id + ".zip "+ path_storage)
    return utils.response_json(
        True,
        code=200,
        message="upload csv waypoint successfully",
        data=""
    )


@app.route("/download/waypoint", methods=["GET"])
@utils.login_required
def download_waypoint():
    if request.args and ("area_id" in request.args):
        area = Area.query.filter(
            Area.area_id == request.args.get('area_id')).first()
        # print(area.serialize())
        if area and area.waypoint_uploaded:
            csv_file = glob.glob(area.waypoint_path +
                                 "/*.csv")[0].split("/")[-1]
            return send_from_directory(area.waypoint_path, csv_file, as_attachment=True)

    return utils.response_json(
        False,
        message="Download failed! Mission parameters request area_id or not exist id in database",
        code=301,
        data=""
    )


@app.route("/delete/waypoint", methods=["DELETE"])
@utils.login_required
def delete_waypoint():
    receive = json.loads(request.data.decode("utf8"))
    if receive and ("area_id" in receive):
        area = Area.query.filter(Area.area_id == receive['area_id']).first()
        if area.waypoint_uploaded:
            os.system("rm -rf " + area.waypoint_path)

        area.waypoint_path = ""
        area.waypoint_uploaded = False
        db.session.commit()
        return utils.response_json(
            True,
            message="Delete waypoint  successfully",
            code=200,
            data=receive
        )
    return utils.response_json(
        False,
        message="Delete waypoint failed! Missing input",
        code=301,
        data=receive
    )


@app.route("/list/mapfile", methods=["GET"])
@utils.login_required
def list_map_file():
    if request.args and ('area_id' in request.args):
        area = Area.query.filter(
            Area.area_id == request.args.get('area_id')).first()
        if (None != area) and area.map_uploaded:
            list_mapfile = glob.glob(area.map_path + "/*.pcd")
            return utils.response_json(
                True,
                message="Successfully!",
                code=200,
                data=[('/'+'/'.join(path.split('/')[path.split('/').index('static'):]))
                      for path in list_mapfile]
            )
    return utils.response_json(
        False,
        message="List of map file failed! Missing input or area don't exist",
        code=301,
        data=request.form
    )


@app.route("/list/waypoint")
@utils.login_required
def list_waypoint():
    if request.args and ("area_id" in request.args):
        area = Area.query.filter(
            Area.area_id == request.args.get('area_id')).first()
        if (None != area) and area.waypoint_uploaded:
            waypoint_path = glob.glob(area.waypoint_path + "/*.csv")[0]
            df = pd.read_csv(waypoint_path)
            data = {}
            data["format"] = ["x", "y", "z", "yaw", "velocity", "quater_x"	,"quater_y","quater_z","quater_w"]
            data["data"] = []
            for i in df.index:
                data["data"].append([
                    df["x"][i], df["y"][i], df["z"][i], df["yaw"][i], df["velocity"][i], df["quater_x"][i],
                    df["quater_y"][i],df["quater_z"][i],df["quater_w"][i]
                ])
            
            return utils.response_json(
                True,
                message="Successfully!",
                code=200,
                data=data
            )
    return utils.response_json(
        False,
        message="List of waypoint failed! Missing input or area don't exist",
        code=301,
        data=request.form
    )
