from app import db, app
from flask import request, render_template, url_for
from flask import send_from_directory, send_file, jsonify
from flask import make_response, redirect, session

from app.models.models import VehicleData
from app.models.models import Vehicle
from app.utils import utils
from app.utils.params import *
import paho.mqtt.client as mqtt

import uuid
import time
import os
import json
import glob

# MQTT Protocol for system
# --------------- Start ---------------------------------

client = mqtt.Client("Flask_Server", clean_session=True)


def on_connect(client, userdata, flags, rc):
    print("Connected with result code: " + str(rc))
    if 0 == rc:
        client.subscribe("vehicle/#")


def on_message(client, userdata, message):
    msg = message.payload.decode('utf8')

    vehicle_id = message.topic.split("/")[2]
    area_id = message.topic.split("/")[1]
    prefix = message.topic.split("/")[-1]

    if Vehicle.query.filter(Vehicle.vehicle_id == vehicle_id, Vehicle.area_id == area_id).first():
        vehicle_data = VehicleData.query.filter(
            VehicleData.vehicle_id == vehicle_id).first()
        try:
            if vehicle_data:
                # print("store last message")
                vehicle_data.time_create = str(time.time())
                if prefix == 'feedback':
                    print("type message feedback id: ", vehicle_id)
                    vehicle_data.feedback_msg = json.dumps(json.loads(msg))
                elif prefix == 'connected':
                    print("store status connect: ", msg, " - id: ", vehicle_id)
                    vehicle_data.connect_msg = int(msg)
                elif 'params/confirm' in message.topic:
                    print("confirm message params topic")
                    vehicle_data.setting_params_msg = json.dumps(
                        json.loads(msg))
                elif 'mission/confirm' in message.topic:
                    vehicle_data.mission_msg = json.dumps(json.loads(msg))
                elif 'system/confirm' in message.topic:
                    vehicle_data.init_system_confirm_topic = json.dumps(
                        json.loads(msg))
                db.session.commit()
        except:
            print(type(msg))


def on_disconnect(client, userdata, rc):
    print("client disconnected")
    # exit(0)


client.on_connect = on_connect
client.on_message = on_message
client.on_disconnect = on_disconnect
client.username_pw_set('admin', "Fsoft@12345")
# client.connect("54.169.52.29", 1883)
# client.loop_start()

# client.disconnect()
# ------------------ End MQTT -----------------------

# HTTP request get Value
# ------------------------- Start --------------------------------


@app.route("/vehicle/feedback", methods=["GET"])
@utils.login_required
def get_data_feedback():
    try:
        vehicle_id = request.args.get('vehicle_id')
        print(vehicle_id)
        vehicle_data = VehicleData.query.filter(
            VehicleData.vehicle_id == vehicle_id).first()
        if vehicle_data:
            msg = json.loads(vehicle_data.feedback_msg)
            msg['connected'] = vehicle_data.connect_msg
            return utils.response_json(
                False,
                code=200,
                message="Successfully!",
                data=msg
            )
        else:
            return utils.response_json(
                False,
                code=301,
                message="Failed",
                data=""
            )
    except:
        return utils.response_json(
            False,
            code=301,
            message="Failed! Don't exist vehicle or missing input",
            data=""
        )


@app.route("/vehicle/upload/params", methods=["POST"])
@utils.login_required
def vehicle_upload_params():
    receive = None
    if request.form:
        receive = request.form
    else:
        receive = json.loads(request.data.decode("utf8"))

    if receive and ('vehicle_id' in receive) and ('key' in receive) and ('value' in receive):
        vehicle = Vehicle.query.filter(Vehicle.vehicle_id ==
                                       receive['vehicle_id']).first()
        if (vehicle != None) and (vehicle.status == ACTIVE_STATUS):
            vehicle_data = VehicleData.query.filter(
                VehicleData.vehicle_id == receive['vehicle_id']).first()

            msg = json.loads(vehicle_data.setting_params_msg)
            msg['timestamp'] = time.time()
            msg['received'] = 0
            if receive['key'] in ['max_speed', 'safety_range']:
                msg['settings'][receive['key']] = receive['value']

            vehicle_data.setting_params_msg = json.dumps(msg)
            db.session.commit()
            client.publish(vehicle.setting_params_topic, json.dumps(msg))
            return utils.response_json(
                True,
                message="Setting params successfully!",
                code=200,
                data=receive
            )
    return utils.response_json(
        False,
        message="Setting params fail!",
        code=301,
        data=receive
    )


# ------------------------- END ----------------------------------
