$(document).ready(function(){
    $pathname=$(location).attr("pathname");
    $('a[href="'+$pathname+'"]').addClass('active')
})