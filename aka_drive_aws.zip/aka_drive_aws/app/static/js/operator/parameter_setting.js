$(document).ready(function () {
    $.ajax({
        method: 'GET',
        url: '/list/vehicle',
        success: function (res) {
            for (let i = 0; i < res.data.length; i++) {
                let d = res.data[i]
                $("#vehicle_sl").append(
                    $("<option>").text(d.name).val(d.vehicle_id)
                )
            }
            $("#vehicle_sl").change(function () {
                showParam();
            })
        },
    });
})
function showParam() {
    var v_id = $("#vehicle_sl").val()
    if (v_id != "") {
        $.ajax(
            {
                method: 'GET',
                url: '/get/params?vehicle_id=' + v_id,
                success: function (res) {
                    var items = res.data.settings;
                    $("#params_table").removeClass("hide")
                    $("#params_table tbody").empty()
                    for (let key in items) {
                        let row_add = $("<tr>").append(
                            $("<td>").html($("<div class='area-info'>").text(key)),
                            $("<td>")
                                .append(
                                    $("<div class='row px-3'>").append(
                                        $('<input type="range" name="vol" min="0" step="0.1" max="5">')
                                            .attr({
                                                'class': 'col-md-10 v-align-middle',
                                                'id': key,
                                            }).val(items[key])
                                            .on('input', function () {
                                                changeValue(key, items[key])
                                            }),
                                        $("<label style='padding-top:6px'>")
                                            .attr({
                                                'for': key,
                                                'class': 'col-md-2 v-align-middle'
                                            })
                                            .text(items[key])
                                    )
                                ),
                            $("<td>").html($("<div class='area-info'>").append(
                                $("<a>").attr(
                                    {
                                        "href": "#",
                                        "id": "save-btn-" + key,
                                        "class": "a-btn-warning disable"
                                    }).text("Update")
                                    .click(() => {
                                        updateValue(key, v_id)
                                    }))
                            ),
                        )

                        $("#params_table tbody").append(row_add)
                    }
                }
            }
        )
    } else {
        $("#params_table").addClass("hide")
    }
}
function changeValue(key, value) {
    $("label[for=" + key + "]").text($("#" + key).val());
    if ($("#" + key).val() != value) {
        $("#save-btn-" + key).removeClass("disable")
    }
    else {
        $("#save-btn-" + key).addClass("disable")
    }
}

function updateValue(key, id) {
    $("#confirmUpdate").modal("show");
    $("#confirmUpdate #yes").click(function () {
        $.ajax({
            method: 'POST',
            url: '/vehicle/upload/params',
            data: JSON.stringify({
                "vehicle_id": id,
                "key": key,
                "value": $("#" + key).val()
            }),
            contentType: "application/json",
            success: function (res) {
                var newValue=res.data.value;
                $("#save-btn-" + key).addClass("disable");
                $("#confirmUpdate").modal("hide");
                $("#confirmUpdate #yes").off("click")
                $("#" + key).on('input', function(){
                    changeValue(key, newValue)
                })
            },
        });
    })

}