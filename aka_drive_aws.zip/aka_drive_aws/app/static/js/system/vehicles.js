$(document).ready(function () {
    $.ajax({
        method: 'GET',
        url: '/list/area',
        success: function (res) {
            createVehiclesTable(res.data)
        }
    })

})
function createVehiclesTable(areaList) {
    $.ajax({
        method: 'GET',
        url: '/list/vehicle',
        success: function (res) {
            for (let i = 0; i < res.data.length; i++) {
                let d = res.data[i]
                let isActive = d.status == "ACTIVE" ? "on" : 'off'

                let sel = $("<select>").attr({
                    "class": "col-12 form-control-sm",
                    "id": "area-" + d.vehicle_id
                }).append(
                    $("<option value=''>").text("Select area")
                ).val("")
                areaList.forEach(function (v, k) {
                    sel.append(
                        $("<option>").text(v.area_id)
                    )
                })
                if (d.area_id != null) {
                    sel.val(d.area_id)
                }

                $("#vehicles_table").append(
                    $("<tr>").append(
                        $("<td class='input-td'>").append(
                            $("<input type='text' class='form-control border-0' placeholder='Enter vehicle name'>")
                                .val(d.name)
                                .attr('id', 'name-' + d.vehicle_id)
                                .on("input", function () {
                                    activeSaveBtn(d)
                                })
                        ),
                        $("<td class='select-td'>").append(
                            sel.change(function () {
                                activeSaveBtn(d);
                            })
                        ),
                        $("<td>").text(new Date(parseFloat(d.time_create) * 1000).toLocaleDateString('en-US', { hour12: true })),
                        $("<td class='text-center' style='width:130px'>").append(
                            $("<input>").attr({
                                "id": "active-toggle-" + i,
                                "type": "checkbox",
                                "data-size": "xs",
                            })
                        ),

                        $("<td style='width:115px'>").append(
                            $("<a disabled>").attr(
                                {
                                    "href": "#",
                                    "id": "save-btn-" + d.vehicle_id,
                                    "class": "a-btn-warning disable"
                                }
                            )
                                .text("Save")
                                .click(() => {
                                    updateInfo(d.vehicle_id)
                                })
                            ,
                            " | ",
                            $("<a>").attr({ "href": "#" })
                                .addClass("a-btn-danger")
                                .text("Delete")
                                .on("click", function () {
                                    deleteVehicle(d.vehicle_id)
                                })
                        )
                    )
                )
                $("#" + "active-toggle-" + i).bootstrapToggle({
                    on: 'Active',
                    off: 'Deactive'
                })
                $("#" + "active-toggle-" + i).bootstrapToggle(isActive)
                    .change(function () {
                        let stt = $('#active-toggle-' + i).prop('checked');
                        updateStatus(d.vehicle_id, stt)
                    })
            }
        },
    });
}
function updateStatus(id, stt) {
    $.ajax({
        method: 'PUT',
        url: '/active/vehicle',
        data: JSON.stringify({
            vehicle_id: id,
            status: stt ? "ACTIVE" : "DEACTIVE"
        }),
        contentType: "application/json",
        success: function (res) {
        }
    })
}

function updateInfo(id) {
    if (validateUpdateInfo(id)) {
        $("#confirmUpdate").modal("show");
        $("#confirmUpdate #yes").click(function () {
            $.ajax({
                method: 'PUT',
                url: '/update/vehicle',
                data: JSON.stringify({
                    vehicle_id: id,
                    area_id: $("#area-" + id).val(),
                    name: $.trim($("#name-" + id).val())
                }),
                contentType: "application/json",
                success: function (res) {
                    $("#confirmUpdate").modal("hide");;
                    $("#save-btn-"+id).addClass("disable");
                    $("#confirmUpdate #yes").off("click");
                    $("#name-"+id).on('input',function(){
                        activeSaveBtn(res.data)
                    })
                    $("#area-"+id).on('change',function(){
                        activeSaveBtn(res.data)
                    })
                }
            })
        })
    }


}
function validateUpdateInfo(id) {
    if ($.trim($("#name-" + id).val()) == "") {
        $("#alert").text("Please enter vehicle name");
        $("#alert").fadeIn(1000);
        setTimeout(function () {
            $('#alert').fadeOut(1000);
        }, 2000);
        return false;
    }
    if ($("#area-" + id).val() == "") {
        $("#alert").text("Please select area");
        $("#alert").fadeIn(1000);
        setTimeout(function () {
            $('#alert').fadeOut(1000);
        }, 2000);
        return false;
    }
    return true
}
function activeSaveBtn(d) {
    if ($.trim($("#name-" + d.vehicle_id).val()) != d.name || $("#area-" + d.vehicle_id).val() != d.area_id) {
        $("#save-btn-" + d.vehicle_id).attr("class", "a-btn-warning");
    } else {
        $("#save-btn-" + d.vehicle_id).attr("class", "a-btn-warning disable");
    }
}

function deleteVehicle(id) {
    $("#confirmDelete").modal("show");
    $("#confirmDelete #yes").click(function () {
        $("#confirmDelete").modal("hide");
        $.ajax({
            method: 'DELETE',
            url: '/delete/vehicle',
            data: JSON.stringify({
                vehicle_id: id,
            }),
            contentType: "application/json",
            success: function (res) {
                location.reload();
            }
        })
    })

}