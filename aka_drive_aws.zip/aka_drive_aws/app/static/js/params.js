HOST = "http://54.179.218.99"
PORT = "8080"
AREA = { area_name: "silicon", lat: 10.835103, lng: 106.820030};
PARAMS = "?vehicle_id=fville&area=" + AREA.area_name;