#!/home/ubuntu/fville_final/env/bin/python
from app import app
if __name__ == "__main__":
    app.run()
