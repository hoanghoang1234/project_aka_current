
function get_finished_trip()
{
    $.ajax({
        url: "/finished-trips",
        type: "GET",
        dataType: 'json',
        success: function (data) {
            console.log(" finished_trip format : " + JSON.stringify(data))
            if (document.getElementById("finished_trip")) { document.getElementById("finished_trip").innerHTML = data.data + " (trips)"; }

            var html = '';
            data.trips.sort((function (a, b) { return new Date(parseFloat(b.time_create)) - new Date(parseFloat(a.time_create)) }));
            var table_rows = 10;
            var index =  ((data.trips.length < table_rows)? data.trips.length: table_rows);

            for(var i = 0; i < index; i++)
            {
                var datetime = new Date(parseFloat(data.trips[i].time_create)*1000);
                html += '<tr>';
                html += '<td>' + data.trips[i].username + '</td>';
                var tripname = data.trips[i].trip_name.split("-"); 
                html += '<td>' + tripname[0] + '</td>';
                html += '<td>' + tripname[1] + '</td>';
                html += '<td>' + datetime.toLocaleString('en-US', { hour12: false }) + '</td>';
                html += '</tr>';
            } 
            $('#finished_trip_table_body').html(html);
        }
    });

}

$(document).ready(function () {
    // get_finished_trip();
    // setInterval(function(){
    //     get_finished_trip();
    // }, 5000);
});