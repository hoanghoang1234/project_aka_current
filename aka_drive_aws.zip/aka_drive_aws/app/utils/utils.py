import jwt
import time
from app import app
from flask import request, redirect, url_for, session
import json
import bcrypt
import base64
from functools import wraps
from datetime import datetime
from app.utils.params import *
import string
import random

#app.config.update(dict(PREFERRED_URL_SCHEME = 'https'))


def encode_token(data):
    '''
    Input: Json data format
    {
            'username': value,
            'role': 'ADMIN',
            'timestamp': timestamp
    }
    return: string token encode
    '''
    return jwt.encode(data, 'secrect', algorithm='HS256').decode('utf8')


def decode_token(token_str):
    '''
    Input is a token string. Get from headers request
    return: json data fromat
    '''
    return jwt.decode(token_str, 'secrect', algorithm='HS256')


def encode64(data):
    '''
    Encode data based on base64 algorithm
    '''
    return base64.b64encode(bytes(data, "utf8")).decode("utf8")


def decode64(data):
    '''
    Decode data based on base64 algorithm
    '''
    return base64.b64decode(bytes(data, "utf8")).decode("utf8")


def encode_bcrypt(password):
    '''
    Hash password based on bcrypt. 
    Salt random generate based on bcrypt
    '''
    return bcrypt.hashpw(password.encode("utf8"), bcrypt.gensalt()).decode("utf8")


def check_password(password, hashed_password):
    '''
    Compare password of user enter with password store in database 
    '''
    return bcrypt.checkpw(password.encode('utf8'), hashed_password.encode("utf8"))


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token_str = request.cookies.get('token')
        # print(token_str)
        if token_str:
            token_json = decode_token(token_str)
            username = token_json['username']
            res = session.get('username')
            if username == res:
                return f(*args, **kwargs)
        return redirect(url_for('login', _external=True, _scheme=MODE_SYSTEM))
    return decorated_function


def datetime2timestamp(datetime_str, format):
    return datetime.timestamp(datetime.strptime(datetime_str, format))


def timestamp2datetime(timestamp, format):
    return datetime.fromtimestamp(timestamp).strftime(format)


def response_json(success, message, code, data):
    return {
        "success": success,
        "message": message,
        "code": code,
        "data": data
    }


def password_generate(length=30):
    pass_source = string.ascii_letters + string.digits \
        + "@#%&*+,-.:;?^_"
    return ''.join(random.choice(pass_source) for i in range(length))

''' 
def vehicle_authen(f)
  @wraps(f)
  def decorated_function(* args, **kwargs):
    token_str = request.args.get('token')
    if token_str:
      token_json = decode_token(token_str)
      vehicle_id = token_json['username']
      res = session.get('username')
      if username == res:
        return f(*args, **kwargs)
    return "Error authen"
  return decorated_function
'''
