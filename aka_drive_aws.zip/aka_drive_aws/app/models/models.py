from flask_sqlalchemy import SQLAlchemy
from app import db
import json
from app.utils.params import *
from app.utils import utils
import time


class User(db.Model):
    __tablename__ = "users"
    username = db.Column(db.String(100), unique=True,
                         primary_key=True, nullable=False)
    password = db.Column(db.String(500))
    fullname = db.Column(db.String(100))
    phone = db.Column(db.String(100))
    avatar = db.Column(db.String(100))
    role = db.Column(db.String(10))
    address = db.Column(db.String(500))
    career = db.Column(db.String(100))
    time_create = db.Column(db.String(100))
    status = db.Column(db.String(100))
    email = db.Column(db.String(100))

    def serialize(self):
        return {
            "username": 	self.username,
            "password": 	self.password,
            "name": 		self.fullname,
            "phone": 	 	self.phone,
            "avatar": 	 	self.avatar,
            "role": 	 	self.role,
            "address":  	self.address,
            "career": 		self.career,
            "time_create": 	float(self.time_create),
            "status": 		self.status,
            "email":        self.email
        }


class Area(db.Model):
    __tablename__ = "areas"
    area_id = db.Column(db.String(100), unique=True,
                        primary_key=True, nullable=False)
    map_path = db.Column(db.String(200))
    map_uploaded = db.Column(db.Boolean)
    waypoint_path = db.Column(db.String(200))
    waypoint_uploaded = db.Column(db.Boolean)
    info = db.Column(db.String(1000))
    time_create = db.Column(db.String(100))
    status = db.Column(db.String(100))

    def serialize(self):
        return {
            "area_id": self.area_id,
            "map_path": self.map_path,
            "map_uploaded": self.map_uploaded,
            "waypoint_path": self.waypoint_path,
            "waypoint_uploaded": self.waypoint_uploaded,
            "info": self.info,
            "time_create": float(self.time_create),
            "status": self.status
        }


class Vehicle(db.Model):
    __tablename__ = "vehicles"
    vehicle_id = db.Column(db.String(100), unique=True,
                           primary_key=True, nullable=False)
    name = db.Column(db.String(100))
    setting = db.Column(db.String(2000))
    area_id = db.Column(db.String(100))
    time_create = db.Column(db.String(100))
    mqtt_user = db.Column(db.String(100))
    mqtt_pass = db.Column(db.String(100))
    
    feedback_topic = db.Column(db.String(200))
    connect_status_topic = db.Column(db.String(200))
    setting_params_topic = db.Column(db.String(200))
    setting_params_confirm_topic = db.Column(db.String(200))
    mission_topic = db.Column(db.String(200))
    mission_confirm_topic = db.Column(db.String(200))
    init_system_topic = db.Column(db.String(200))
    init_system_confirm_topic = db.Column(db.String(200))

    status = db.Column(db.String(100))

    def serialize(self):
        return {
            "vehicle_id": self.vehicle_id,
            "name": self.name,
            "setting": json.loads(self.setting),
            "area_id": self.area_id,
            "time_create": float(self.time_create),
            "mqtt_user": self.mqtt_user,
            "mqtt_pass": self.mqtt_pass,
            "feedback_topic": self.feedback_topic,
            "connect_status_topic": self.connect_status_topic,
            "setting_params_topic": self.setting_params_topic,
            "setting_params_confirm_topic": self.setting_params_confirm_topic,
            "mission_topic": self.mission_topic,
            "mission_confirm_topic": self.mission_confirm_topic,
            "init_system_topic": self.init_system_topic,
            "init_system_confirm_topic": self.init_system_confirm_topic,
            "status": self.status
        }


class VehicleData(db.Model):
    __tablename__ = "vehicles_data"
    vehicle_id = db.Column(db.String(100), unique=True,
                           primary_key=True, nullable=False)
    # message = db.Column(db.String(1000))
    # topic = db.Column(db.String(100))
    # connected = db.Column(db.Integer)

    feedback_msg = db.Column(db.String(2000))
    connect_msg = db.Column(db.Integer)
    setting_params_msg = db.Column(db.String(2000))
    mission_msg = db.Column(db.String(2000))
    init_system_msg = db.Column(db.String(2000))

    time_create = db.Column(db.String(100))

    def serialize(self):
        return {
            "vehicle_id": self.vehicle_id,
            "feedback_msg": json.loads(self.feedback_msg),
            "connect_msg": self.connect_msg,
            "setting_params_msg": json.loads(self.setting_params_msg),
            "mission_msg": json.loads(self.mission_msg),
            "init_system_msg": json.loads(self.init_system_msg),
            "time_create": float(self.time_create)
        }


class API(db.Model):
    __tablename__ = "apis"
    api_id = db.Column(db.String(100), unique=True,
                       primary_key=True, nullable=False)
    name = db.Column(db.String(100))
    url = db.Column(db.String(100))
    data_format = db.Column(db.String(1000))
    response = db.Column(db.String(1000))
    method = db.Column(db.String(100))
    category = db.Column(db.String(100))
    time_create = db.Column(db.String(100))

    def serialize(self):
        return {
            "api_id": self.api_id,
            "name": self.name,
            "url": self.url,
            "data_format": json.loads(self.data_format),
            "response": json.loads(self.response),
            "category": self.category,
            "method": self.method,
            "time_create": float(self.time_create)
        }
# class Trip(db.Model):
#     __tablename__ = "trips"
#     trip_id = db.Column(db.Integer, unique=True,
#                         primary_key=True, nullable=False)
#     trip_name = db.Column(db.String(100), nullable=False)
#     info = db.Column(db.String(500), nullable=False)
#     time_create = db.Column(db.String(100))
#     username = db.Column(db.String(50), nullable=False)
#     status = db.Column(db.String(100), nullable=False)

#     def __repr__(self):
#         return '<Trip ID %r>' % self.trip_id

#     def serialize(self):
#         return {
#             "trip_id": 		self.trip_id,
#             "trip_name":	self.trip_name,
#             "info": 		json.loads(self.info),
#             "time_create": 	self.time_create,
#             "username": 	self.username,
#             "status": 		self.status
#         }


db.create_all()
admin = User(
    username="admin",
    password=utils.encode_bcrypt("Fsoft@12345"),
    fullname="Root Account",
    time_create=str(time.time()),
    status=ACTIVE_STATUS,
    role=ADMIN_ROLE,
    avatar=DEFAULT_AVATAR
)
if not User.query.filter(User.username == "admin").all():
    db.session.add(admin)
    db.session.commit()
