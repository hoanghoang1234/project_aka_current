$(document).ready(function () {
    var form_edit_enable = false;
    $("#edit-toggle-btn").click(function () {
        form_edit_enable = !form_edit_enable;
        if (form_edit_enable === true) {
            // $("input[name='username']").prop("disabled", false);
            $("input[name='email']").prop("disabled", false);
            $("input[name='phone']").prop("disabled", false);
            $("input[name='profession']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
            $("input[name='']").prop("disabled", false);
        }else{
            // $("input[name='username']").prop("disabled", true);
            $("input[name='email']").prop("disabled", true);
            $("input[name='phone']").prop("disabled", true);
            $("input[name='profession']").prop("disabled", true);
        }
    })
})