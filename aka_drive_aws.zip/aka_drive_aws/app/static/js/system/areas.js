$(document).ready(function () {
    $.ajax({
        method: 'GET',
        url: '/list/area',
        success: function (res) {
            for (let i = 0; i < res.data.length; i++) {
                let name = res.data[i].area_id;
                let info = res.data[i].info;
                let map_uploaded = res.data[i].map_uploaded;
                let waypoint_uploaded = res.data[i].waypoint_uploaded;
                let status = res.data[i].status;
                let time_create = res.data[i].time_create;
                if (status === "ACTIVE") {
                    $("input#file_upload").remove()
                    $("#upload_file_form").append($("<input id='file_upload' type='file' name='files' accept='.pcd' multiple hidden/>")
                        .change(function (e) {
                            var listFile = e.target.files;
                            $("#fileListBody p").remove()
                            $("#fileList").modal("show");
                            for (let i = 0; i < listFile.length; i++) {
                                $("#fileListBody").append(
                                    $("<p>").text(listFile[i].name)
                                )
                            }
                            $("#upload_file_form").ajaxForm({
                                uploadProgress: function (event, position, total, percentComplete) {
                                    $(".progress-bar").css('width', percentComplete + "%")
                                    $("#progress-value").html(percentComplete + "%")
                                },
                                complete: function (xhr) {
                                    $("#upload_file_btn").hide()
                                    $("#cancel_btn").text("OK")
                                    $("#cancel_btn").click(function () {
                                        location.reload();
                                    })
                                }
                            })
                            $("#upload_file_btn").click(function () {
                                $("#upload_file_form").submit()
                            })
                        }))
                    $("#areas_table").append(
                        $("<tr>").append(
                            $("<td>").append($("<div class='area-info'>").text(i + 1)),
                            $("<td>").append($("<div class='area-info'>").text(name)),
                            mapComponent(name, map_uploaded),
                            wpComponent(name, waypoint_uploaded),
                            $("<td>").append($("<div class='area-info'>").text(info)),
                            $("<td>").append($("<div class='area-info'>").text(new Date(parseFloat(time_create) * 1000).toLocaleDateString('en-US', { hour12: true }))),
                            $("<td class='text-center'>").append($("<div class='area-info'>").html(
                                $("<a>").attr({ "href": "#" })
                                    .addClass("a-btn-danger")
                                    .text("Delete")
                                    .on("click", function () {
                                        deleteArea(name);
                                    }),
                            )),
                        )
                    )
                }
            }
        },
    });
})
function deleteMap(id) {
    $("#confirmDelete").modal("show");
    $("#confirmDelete #yes").click(function () {
        $("#confirmDelete").modal("hide");
        $.ajax({
            url: "/delete/map",
            method: "DELETE",
            contentType: "application/json",
            data: JSON.stringify({ area_id: id }),
            success: function (res) {
                if (res.code == 200) {
                    location.reload();
                }
            }
        });
    })
}
function downloadMap(id) {
    location.href = "/download/map?area_id=" + id
}
function deleteArea(id) {
    $("#confirmDelete").modal("show");
    $("#confirmDelete #yes").click(function () {
        $("#confirmDelete").modal("hide");
        $.ajax({
            url: "/delete/area",
            method: "DELETE",
            contentType: "application/json",
            data: JSON.stringify({ area_id: id }),
            success: function (res) {
                if (res.code == 200) {
                    location.reload();
                } else {
                    console.log(res);
                    if (res.code == 301) {
                        $("#alert").text("Please remove area out of vehicle");
                        $("#alert").fadeIn(1000);
                        setTimeout(function () {
                            $('#alert').fadeOut(1000);
                        }, 2000);
                    }
                }
            }
        });
    })
}
function deleteWP(id) {
    $("#confirmDelete").modal("show");
    $("#confirmDelete #yes").click(function () {
        $("#confirmDelete").modal("hide");
        $.ajax({
            url: "/delete/waypoint",
            method: "DELETE",
            contentType: "application/json",
            data: JSON.stringify({ area_id: id }),
            success: function (res) {
                if (res.code == 200) {
                    location.reload();
                }
            }
        });
    })
}

function uploadWP(id) {
    $("#upload_wp_form").append(
        $("<input id='file_upload_wp' type='file' name='files' accept='.csv' multiple hidden/>").change((e) => {
            var listFile = e.target.files;
            $("#fileListBodyWP p").remove()
            for (let i = 0; i < listFile.length; i++) {
                $("#fileListBodyWP").append(
                    $("<p>").text(listFile[i].name)
                )
            }
            $("#fileListWP").modal("toggle");
        }).click()
    )
    $("#upload_wp_form input[name='area_id']").val(id)
    $("#upload_wp_form").ajaxForm({
        uploadProgress: function (event, position, total, percentComplete) {
            $("#wp_progress_bar").css('width', percentComplete + "%")
            $("#wp_progress_value").html(percentComplete + "%")
        },
        complete: function (xhr) {
            $("#upload_wp_btn").remove()
            $("#cancel_wp_btn").text("OK").addClass('w-100').click(() => {
                location.reload();
            })
        }
    })
    $("#upload_wp_btn").click(() => {
        $("#upload_wp_form").submit()
    })
}

function downloadWP(id) {
    location.href = "/download/waypoint?area_id=" + id
}

var mapComponent = (id, map_uploaded) => {
    // init 3 button
    var upload_map_btn_e = $('<a href="#" class="px-2 a-btn-warning">')
        .html('<i class="fas fa-upload"></i>')
        .click(function () {
            $("input[name='area_id']").val(id);
            $("#file_upload").click();
        })
    var download_map_btn_e = $('<a href="#">')
        .html('<i class="fas fa-download">')
        .click(() => downloadMap(id))
        .attr("class", "px-2 a-btn-success disable")

    var delete_map_btn_e = $('<a href="#" data-toggle="modal">')
        .attr("class", "px-2 a-btn-danger disable")
        .html('<i class="fas fa-trash"></i>')
        .click(function () {
            deleteMap(id)
        })

    // ------------------

    var status_map_e = $('<a class="px-2">').html('<i class="fas fa-circle secondary"></i>')
    if (map_uploaded == true) {
        status_map_e.html('<i class="fas fa-check-circle success">')
        download_map_btn_e.removeClass("disable")
        delete_map_btn_e.removeClass("disable")
    }
    return $("<td class='text-center'>").append(
        status_map_e,
        upload_map_btn_e,
        download_map_btn_e,
        delete_map_btn_e
    )
}

var wpComponent = (id, wp_uploaded) => {
    var status_wp_e = $('<a class="px-2">').html('<i class="fas fa-circle secondary">')

    // init 3 button
    var upload_wp_btn_e = $('<a class="px-2 a-btn-warning">')
        .html('<i class="fas fa-upload"></i>')
        .click(() => {
            uploadWP(id)
        })
    var download_wp_btn_e = $('<a class="px-2 a-btn-success disable">')
        .html('<i class="fas fa-download"></i>')
        .click(() => {
            downloadWP(id)
        })
    var delete_wp_btn_e = $('<a class="px-2 a-btn-danger disable">')
        .html('<i class="fas fa-trash">')
        .click(() => {
            deleteWP(id)
        })
    // ----------------

    if (wp_uploaded == true) {
        status_wp_e.html('<i class="fas fa-check-circle success">')
        download_wp_btn_e.removeClass("disable")
        delete_wp_btn_e.removeClass("disable")
    }
    return $("<td class='p-relative text-center'>").append(
        status_wp_e,
        upload_wp_btn_e,
        download_wp_btn_e,
        delete_wp_btn_e
    )
}
