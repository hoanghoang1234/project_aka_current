MYSQL_HOST = "ls-9a4c33e0b21ba4ac757687f8eca25db0718bd041.cc6drjm8hklv.ap-southeast-1.rds.amazonaws.com"
MYSQL_PASS = "Ah8Ze1wG`U47TN>k&-&QT4>vQj,C,8Ii"
MYSQL_USERNAME = "dbmasteruser"
MYSQL_DB = "akadrive_ms"

UPLOAD_FOLDER = '/static/files_upload'

ACTIVE_STATUS = "ACTIVE"
INACTIVE_STATUS = "INACTIVE"

ADMIN_ROLE = "ADMIN"
USER_ROLE = "USER"
DRIVE_ROLE = "DRIVE"
OPERATOR_ROLE = "OPERATOR"

DEFAULT_AVATAR = "/static/avatar/default_avatar.png"

OPEN_STATUS = "OPEN"
DONE_STATUS = "DONE"
CANCEL_STATUS = "CANCEL"
PROGRESS_STATUS = "PROGRESS"
OUTDATE_STATUS = "OUTDATE"

MODE_SYSTEM = "http"

API_TABLE_COLUMN = ["api_id","name", "url", "dt_format", "response", "method", "category"]

MAP_TABLE_COLUMN = ['map_id', "name", "info"]
